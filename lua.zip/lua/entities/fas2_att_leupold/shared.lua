ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Leupold MK4"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Attachments"
ENT.Attachment = "leupold"