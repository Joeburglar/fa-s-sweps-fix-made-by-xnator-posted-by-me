ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Tritium Sights"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Attachments"
ENT.Attachment = "tritiumsights"