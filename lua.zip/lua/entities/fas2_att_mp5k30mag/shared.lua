ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "MP5K 30RND Mag"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Attachments"
ENT.Attachment = "mp5k30mag"